import React from "react";
import Login from "./Login";

var Loggedin = false;

function renderConditionally() {
  if (Loggedin === true) {
    return <h1>hello</h1>;
  } else {
    return <Login />;
  }
}

function App() {
  return
  <div className="container">{renderConditionally()}</div>;
}

export default App;
